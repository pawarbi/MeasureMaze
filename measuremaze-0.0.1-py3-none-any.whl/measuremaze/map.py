from graphviz import Digraph
from IPython.display import display
import networkx as nx
import numpy as np
import pandas as pd
import sempy.fabric as fabric
from sempy.fabric import FabricDataFrame
from shlex import quote

## To generate pandas dataframe containing the dependencies using semantic-link
def get_dependencies(dataset, workspace):
    

    """
    Returns dependecies of measures and calculated columns in specified dataset in a premium workspace. 
    Note that this works in Fabric notebook only but could easily be refactored for non-Premium and even for local models using APIs/XMLA.

    Note on how this works : 
    Use two DMVs, one to get dependencies and another to get folders. Join those two together to get the result df.
    To distinguish between a measure and a column, for columns the object names are Table[ColumnName]. 
    Measures and Calculated tables are just Object names.
    DAX Expression is not used anywhere. This is just for reference if the user neeeds it.

    Inputs:
        dataset : dataset id or name
        workspace: Premium workspace id or name

    Returns:
        pandas dataframe with columns: Object Name, Expression, Dependent on, Type, Folder
        Folder column has format : <TableName>\<Folder Name>\<Folder Name>

    """
    import warnings

    with warnings.catch_warnings(): #suppress sempy warnings
        warnings.simplefilter(action='ignore', category=UserWarning)

        dmv_dependency_query = """
            SELECT [OBJECT_TYPE], [TABLE], [OBJECT], [EXPRESSION], 
            [REFERENCED_OBJECT_TYPE], [REFERENCED_TABLE], [REFERENCED_OBJECT] 
            FROM $SYSTEM.DISCOVER_CALC_DEPENDENCY
            WHERE OBJECT_TYPE = 'MEASURE' OR OBJECT_TYPE = 'CALC_COLUMN'
        """

        dmv_folder_query = """
            SELECT [Name], [DisplayFolder] FROM $SYSTEM.TMSCHEMA_MEASURES
        """

        dependency_df = fabric.evaluate_dax(
            dataset=dataset,
            workspace=workspace,
            dax_string=dmv_dependency_query
        )

        folders_df = (
            fabric.evaluate_dax(
                dataset=dataset,
                workspace=workspace,
                dax_string=dmv_folder_query
            )
            .assign(OBJECT_TYPE="MEASURE") # dummy column for joining
        )

        merged_df = (
            dependency_df
            .merge(folders_df, left_on=['OBJECT_TYPE', 'OBJECT'], right_on=['OBJECT_TYPE', 'Name'], how='left')
            .assign(Folder=lambda x: x.TABLE + "\\" + x.DisplayFolder)
            .drop(['Name', 'DisplayFolder'], axis=1)
        )

        result_df = (
            merged_df
            .assign(
                **{
                    'Object Name': lambda x: np.where(
                        x.OBJECT_TYPE == "CALC_COLUMN",
                        x.TABLE + "[" + x.OBJECT + "]", #for calc column, Table[ColumnName]
                        x.OBJECT
                    ),
                    'Dependent on': lambda x: np.where(
                        x.REFERENCED_OBJECT_TYPE.str.contains("COLUMN"),
                        x.REFERENCED_TABLE + "[" + x.REFERENCED_OBJECT + "]",#for calc column, Table[ColumnName]
                        x.REFERENCED_OBJECT
                    )
                }
            )
            .query('REFERENCED_OBJECT_TYPE != "TABLE"')
            .drop(['OBJECT_TYPE', 'OBJECT', 'TABLE', 'REFERENCED_TABLE', 'REFERENCED_OBJECT'], axis=1)
            .rename(columns={'EXPRESSION': 'Expression', 'REFERENCED_OBJECT_TYPE': 'Type'})
            .reindex(columns=['Object Name', 'Expression', 'Dependent on', 'Type', 'Folder'])
            .reset_index(drop=True)
        )

    return result_df

## Main class to plot the dependencies using network analysis

class PlotDependencies:
    """
    Initialize with DataFrame df containing four columns  : Object Name, Expression, Dependent on, Type, Folder.
    Use get_dependencies() function to getnerate the required df

    Optional argument:
        folder: default None
        if folder is passed it will filter the df to only include measures from that folder
        folder can be a list containing a list of folder paths.

        Example:
        PlotDependencies(df, folder = ["TableName\folder1\subfolder1","TableName\folder"])

            
    """
    def __init__(self, df, folder=None):
        if folder:
            if isinstance(folder, str):
                df = df[df['Folder'].str.startswith(folder)]
                # df = df[df['Folder'] == folder]
        elif isinstance(folder, list):
            f_start = tuple(folder)
            #added this in case there are many nested folders, 
            #Easier to specify main folder and include all measures below it
            df = df[df['Folder'].str.startswith(f_start)] 
          # df = df[df['Folder'].isin(folder)]
        self.df = df
        self.G = nx.DiGraph()
        for obj in self.df['Object Name'].unique():
            self._add_dependencies(obj)

    def _add_dependencies(self, name, dot=None, highlight=False):
        """Add dependencies for plotting."""
        sub_df_up = self.df[self.df['Dependent on'] == name]
        sub_df_down = self.df[self.df['Object Name'] == name] 
        sub_df = pd.concat([sub_df_up, sub_df_down]) #look up in both columns
        added_edges = set()
        for _, row in sub_df.iterrows():
            target = row['Object Name'] if name == row['Dependent on'] else row['Dependent on']
            edge_key = tuple(sorted([name, target]))
            if edge_key in added_edges:
                continue  # Skip duplicate edges
            added_edges.add(edge_key)
            
            self.G.add_edge(name if name == row['Dependent on'] else target, target if name == row['Dependent on'] else name)
            
            if dot:
                color = ''
                if row['Type'] == 'COLUMN':
                    color = '#33a02c'
                elif row['Type'] == 'MEASURE':
                    color = '#6a3d9a'
                elif row['Type'] == 'CALC_COLUMN':
                    color = 'red'
                elif row['Type'] == 'CALC_TABLE':
                    color = 'red' #to highlight calc_column or calc_table
                
                penwidth = '2' if highlight else '1' #to highlight the node in focus
                dot.node(quote(target), target, color=color, penwidth=penwidth)
                #quote to dela with objects containing characters
                dot.edge(quote(name if name == row['Dependent on'] else target), quote(target if name == row['Dependent on'] else name))

    def plot(self, object_name=None, graph_size='20,20', layout='vertical', dpi=None):
        """Plot graph. Optional object_name, graph_size, layout, and dpi."""
        l = 'TB' if layout == 'vertical' else 'LR'
        dot = Digraph(comment='Dependency Graph')
        dot.attr(rankdir=l, size=graph_size, dpi=dpi)
        dot.attr('node', shape='box', style='rounded', fontsize='12')

        if object_name:
            if isinstance(object_name, str):
                object_name = [object_name]
            for obj in object_name:
                if obj not in self.df['Object Name'].unique() and obj not in self.df['Dependent on'].unique():
                    print(f"Invalid object name: {obj}")
                    continue
                dot.node(quote(obj), obj, color='#1f78b4', penwidth='3')
                self._add_dependencies(obj, dot, True)
        else:
            for obj in self.df['Object Name'].unique():
                self._add_dependencies(obj, dot)

        display(dot)


    def centrality(self, level=1, graph_size='20,20', method='degree', layout='vertical', dpi =None):
        """
        Display centrality nodes. 
        Optional level, graph_size, method, layout and dpi.
        Four centrality methods are supported - degree, closeness, betweenness and eigenvector
        eigenvector is unstable and needs lot of data
        """
        l = 'TB' if layout == 'vertical' else 'LR'

        dot = Digraph(comment='Dependency Graph')
        dot.attr(rankdir=l, size=graph_size, dpi = dpi)
        dot.attr('node', shape='box', style='rounded', fontsize='12')
        
        centrality_methods = {
            'degree': nx.degree_centrality,
            'closeness': nx.closeness_centrality,
            'betweenness': nx.betweenness_centrality,
            'eigenvector': nx.eigenvector_centrality #unstable
        }
        
        if method not in centrality_methods:
            print(f"Invalid method: {method}")
            return

        centrality_scores = centrality_methods[method](self.G)
        top_nodes = sorted(centrality_scores, key=centrality_scores.get, reverse=True)[:level]
        for node in top_nodes:
            dot.node(quote(node), node, color='#1f78b4', penwidth='3')
            self._add_dependencies(node, dot, True)
        
        display(dot)

    def show(self):
        """Return DataFrame with measures and dependency counts."""
        in_degree = dict(self.G.in_degree())
        out_degree = dict(self.G.out_degree())
        centrality_scores = nx.degree_centrality(self.G)

        measures = list(self.df['Object Name'].unique())
        df_show = pd.DataFrame({
            'Object': measures,
            'Upstream Dependencies': [in_degree.get(m, 0) for m in measures],
            'Downstream Dependencies': [out_degree.get(m, 0) for m in measures],
            'Centrality': [centrality_scores.get(m, 0) for m in measures]
        }).sort_values(by='Centrality',ascending=False).reset_index(drop=True)
        
        return df_show

    def depth(self, level=1, graph_size='20,20', layout='vertical', dpi=None):
        """Display object(s) with highest vertical depth of dependencies."""
        def find_depth(node, depth_dict):
            if node in depth_dict:
                return depth_dict[node]
            neighbors = list(self.G.predecessors(node))
            if not neighbors:
                depth_dict[node] = 0
                return 0
            depths = [find_depth(neighbor, depth_dict) for neighbor in neighbors]
            depth_dict[node] = 1 + max(depths)
            return depth_dict[node]

        def plot_upstream(node, dot):
            for predecessor in self.G.predecessors(node):
                filtered_df = self.df[self.df['Object Name'] == predecessor]
                if filtered_df.empty:
                    continue
                row = filtered_df.iloc[0]
                color = ''
                if row['Type'] == 'COLUMN':
                    color = '#33a02c'
                elif row['Type'] == 'MEASURE':
                    color = '#6a3d9a'
                elif row['Type'] == 'CALC_COLUMN':
                    color = 'red'
                elif row['Type'] == 'CALC_TABLE':
                    color = 'red'
                dot.node(quote(predecessor), predecessor, color=color)
                dot.edge(quote(predecessor), quote(node))
                plot_upstream(predecessor, dot)

        depth_dict = {}
        for node in self.G.nodes():
            find_depth(node, depth_dict)

        l = 'TB' if layout == 'vertical' else 'LR'

        dot = Digraph(comment='Dependency Graph')
        dot.attr(rankdir=l, size=graph_size, dpi=dpi)
        dot.attr('node', shape='box', style='rounded', fontsize='12')

        top_nodes = sorted(depth_dict, key=depth_dict.get, reverse=True)[:level]
        for node in top_nodes:
            dot.node(quote(node), node, color='#1f78b4', penwidth='3')
            plot_upstream(node, dot)

        display(dot)



    def find_link(self, object1, object2):
        """Find and plot all dependency links between object1 and object2, in both directions.
            
        """
        dot = Digraph(comment='All Dependency Links')
        dot.attr(rankdir='LR') #Not adding options to change layout, dpi, size for this fn
        dot.attr('node', shape='box', style='rounded', fontsize='12')
        
        found_path = False
        
        for source, target in [(object1, object2), (object2, object1)]:
            if nx.has_path(self.G, source, target):
                all_paths = list(nx.all_simple_paths(self.G, source=source, target=target))
                unique_nodes = set()
                
                for path in all_paths:
                    for node in path:
                        unique_nodes.add(node)
                        filtered_df = self.df[self.df['Object Name'] == node]
                        if filtered_df.empty:
                            continue
                        node_type = filtered_df['Type'].iloc[0]
                        
                        if node_type == 'COLUMN':
                            color = '#33a02c'
                        elif node_type == 'MEASURE':
                            color = '#6a3d9a'
                        elif node_type == 'CALC_COLUMN':
                            color = 'red'
                        elif node_type == 'CALC_TABLE':
                            color = 'red'
                        
                        
                        dot.node(quote(node), node, color=color)
                
                for path in all_paths:
                    for i in range(len(path) - 1):
                        dot.edge(quote(path[i]), quote(path[i + 1]))
                
                found_path = True

        if found_path:
            display(dot)
        else:
            print(f"No dependency link found between {object1} and {object2}.")
