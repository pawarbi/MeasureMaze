## __.init__.py
def function_init():
    print('Successfully Imported Init.py')
