import requests
import pandas as pd
import sempy.fabric as fabric
import json

def build_dataset_catalog():
    '''
    Sandeep Pawar | Fabric.guru
    Build dataset (semnatic model) catalog in Fabric
    '''
    url = "https://analysis.windows.net/powerbi/api"
    token = mssparkutils.credentials.getToken(url)
    headers = {"Authorization": "Bearer " + token}

    response = requests.get("https://api.powerbi.com/v1.0/myorg/groups", headers=headers)
    premium_workspaces = pd.DataFrame(response.json()['value']).query('isOnDedicatedCapacity==True')[["name", "id"]]

    dfs = [
        fabric.list_datasets(ws).assign(workspace=ws) 
        for ws in premium_workspaces['name']
    ]

    catalog = pd.concat(dfs, ignore_index=True)
    cols = ['workspace'] + [col for col in catalog.columns if col != 'workspace']
    return catalog.reindex(columns=cols)



def pbi_table_report( workspace, dataset):
    '''
    Sandeep Pawar | Fabric.guru

    Use sempy to execute DMVs and analyze tables for best practices
    Ver: 0.1
    Warning : I haven not validated the DMVs yet, only for demo currently. I will update later. 

    '''

    table_list = (fabric
        .evaluate_dax(
            workspace=workspace, dataset=dataset,
            dax_string="""select [ID], [Name], [IsHidden],[ExcludeFromModelRefresh] from $SYSTEM.TMSCHEMA_TABLES"""
        )
    ).assign(IsAutoDate=lambda x: x['Name'].str.startswith(('DateTableTemplate', 'LocalDateTable_'))).set_index('ID')

    # Get RI Violation Count
    ir = (fabric
        .evaluate_dax(
            workspace=workspace, dataset=dataset,
            dax_string="""select [Name],[RIViolationCount] from $SYSTEM.TMSCHEMA_TABLE_STORAGES"""
        )
    ).assign(ID=lambda x: x['Name'].str.extract(r'\((\d+)\)$')).set_index('ID')

    # Get calculated columns
    calc_cols = (fabric
        .evaluate_dax(
            workspace=workspace, dataset=dataset,
            dax_string="""select [TableID],[Expression] from $SYSTEM.TMSCHEMA_COLUMNS"""
        )
    ).groupby('TableID').agg(
        Num_Columns=pd.NamedAgg(column='Expression', aggfunc='size'),
        Num_Calc_Columns=pd.NamedAgg(column='Expression', aggfunc='count')
    )
    calc_cols.index.name = 'ID'

    # Join all
    final = table_list.join(ir[['RIViolationCount']]).join(calc_cols).reset_index(drop=True)

    return final



